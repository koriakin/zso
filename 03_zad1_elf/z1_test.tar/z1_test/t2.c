int f();
extern int x[3];

int g() {
    return x[1] + f();
}
