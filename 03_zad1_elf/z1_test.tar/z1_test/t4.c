extern int x[3];

void setx(int idx, int val) {
    x[idx] = val;
}
