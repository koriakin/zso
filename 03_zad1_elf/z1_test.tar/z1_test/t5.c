extern int x[3];

int getx(int idx) {
    return x[idx];
}
