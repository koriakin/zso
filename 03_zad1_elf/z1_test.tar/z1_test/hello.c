int printf(const char *fmt, ...);

void hello() {
	printf("Hello, world!\n");
}
